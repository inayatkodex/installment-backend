import {
  activeMonthlyTotal,
  buildMultiPlanSchedules,
  buildMultiPlanSchedulesWithAllocations,
  buildSchedule,
  buildScheduleWithAllocations,
  combineInstallmentSchedules,
  isValidPlan,
  MultiPlanInput,
  PlanInput,
  summarizeCashInRange,
} from './shop.logic';

const plan = (overrides: Partial<PlanInput> = {}): PlanInput => ({
  items: [{ price: 34400 }],
  downPayment: 4400,
  initialMonthlyPayment: 2000,
  firstDueDate: '2026-11-25',
  rateChanges: [],
  payments: [],
  ...overrides,
});

describe('installment schedule', () => {
  it('records FIFO payment allocations without changing installment rows', () => {
    const input = plan({
      items: [{ price: 3000 }],
      downPayment: 0,
      initialMonthlyPayment: 1000,
      firstDueDate: '2026-01-01',
      payments: [
        {
          id: 'payment-1',
          amount: 2500,
          paidOn: new Date('2026-03-01T10:00:00Z'),
          method: 'Cash',
          note: null,
        },
      ],
    });
    const legacyRows = buildSchedule(input, '2026-03-01');
    const detailed = buildScheduleWithAllocations(input, '2026-03-01');

    expect(detailed.rows).toEqual(legacyRows);
    expect(detailed.allocations).toEqual([
      {
        paymentId: 'payment-1',
        planKey: 'base',
        installmentNo: 1,
        dueDate: '2026-01-01',
        amount: 1000,
      },
      {
        paymentId: 'payment-1',
        planKey: 'base',
        installmentNo: 2,
        dueDate: '2026-02-01',
        amount: 1000,
      },
      {
        paymentId: 'payment-1',
        planKey: 'base',
        installmentNo: 3,
        dueDate: '2026-03-01',
        amount: 500,
      },
    ]);
  });

  it('splits cash between late and current installments and excludes reversed payments', () => {
    const input = plan({
      items: [{ price: 3000 }],
      downPayment: 0,
      initialMonthlyPayment: 1000,
      firstDueDate: '2026-01-01',
    });
    const detailed = buildScheduleWithAllocations(
      {
        ...input,
        payments: [
          {
            id: 'current-cash',
            amount: 2500,
            paidOn: new Date('2026-03-01T10:00:00Z'),
            method: 'Cash',
            note: null,
          },
        ],
      },
      '2026-03-01',
    );
    const summary = summarizeCashInRange(
      [
        { id: 'current-cash', amount: 2500 },
        {
          id: 'reversed-cash',
          amount: 900,
          reversedAt: new Date('2026-03-01T11:00:00Z'),
        },
      ],
      [
        ...detailed.allocations,
        {
          paymentId: 'reversed-cash',
          planKey: 'base',
          installmentNo: 1,
          dueDate: '2026-01-01',
          amount: 900,
        },
      ],
      '2026-03-01',
      '2026-03-01',
    );

    expect(summary).toEqual({
      total: 2500,
      forPeriod: 500,
      late: 2000,
      advance: 0,
      lateByMonth: [
        { month: '2026-01', amount: 1000 },
        { month: '2026-02', amount: 1000 },
      ],
    });
  });

  it('classifies advance and monthly late cash with exact totals', () => {
    const summary = summarizeCashInRange(
      [{ id: 'november-cash', amount: 100000 }],
      [
        {
          paymentId: 'november-cash',
          planKey: 'base',
          installmentNo: 1,
          dueDate: '2026-11-01',
          amount: 70000,
        },
        {
          paymentId: 'november-cash',
          planKey: 'base',
          installmentNo: 2,
          dueDate: '2026-10-01',
          amount: 25000,
        },
        {
          paymentId: 'november-cash',
          planKey: 'base',
          installmentNo: 3,
          dueDate: '2026-12-01',
          amount: 5000,
        },
      ],
      '2026-11-01',
      '2026-11-30',
    );

    expect(summary).toEqual({
      total: 100000,
      forPeriod: 70000,
      late: 25000,
      advance: 5000,
      lateByMonth: [{ month: '2026-10', amount: 25000 }],
    });
  });

  it('returns additive allocation details for multi-plan FIFO payments', () => {
    const multiPlans: MultiPlanInput[] = [
      {
        id: 'a',
        items: [{ name: 'Item A', price: 10000, boughtOn: '2026-10-01' }],
        downPayment: 0,
        initialMonthlyPayment: 7500,
        firstDueDate: '2026-11-25',
        rateChanges: [],
        createdAt: new Date('2026-10-01T00:00:00Z'),
      },
      {
        id: 'b',
        items: [{ name: 'Item B', price: 5000, boughtOn: '2026-11-01' }],
        downPayment: 0,
        initialMonthlyPayment: 3000,
        firstDueDate: null,
        rateChanges: [],
        createdAt: new Date('2026-11-01T00:00:00Z'),
      },
    ];
    const payment = {
      id: 'multi-plan-payment',
      amount: 10500,
      paidOn: new Date('2026-11-25T10:00:00Z'),
      createdAt: new Date('2026-11-25T10:00:00Z'),
      method: 'Cash',
      note: null,
    };
    const legacyRows = buildMultiPlanSchedules(
      multiPlans,
      [payment],
      '2026-11-25',
      '2026-11-25',
    );
    const detailed = buildMultiPlanSchedulesWithAllocations(
      multiPlans,
      [payment],
      '2026-11-25',
      '2026-11-25',
    );

    expect(detailed.schedules).toEqual(legacyRows);
    expect(detailed.allocations.reduce((sum, item) => sum + item.amount, 0)).toBe(
      payment.amount,
    );
    expect(detailed.allocations.map((item) => item.planKey)).toEqual([
      'a',
      'b',
    ]);
  });

  it('creates monthly installments until the balance is paid and adjusts the last amount', () => {
    const rows = buildSchedule(
      plan({ items: [{ price: 34900 }] }),
      '2026-10-28',
    );

    expect(rows).toHaveLength(16);
    expect(rows.slice(0, 15).every((row) => row.expected === 2000)).toBe(true);
    expect(rows[15].expected).toBe(500);
    expect(rows[0].dueDate).toBe('2026-11-25');
    expect(rows[15].dueDate).toBe('2028-02-25');
  });

  it('applies a new monthly amount from its effective installment', () => {
    const rows = buildSchedule(
      plan({
        items: [{ price: 10400 }],
        downPayment: 400,
        rateChanges: [{ fromInstallmentNo: 3, monthlyPayment: 3000 }],
      }),
      '2026-10-28',
    );

    expect(rows.map((row) => row.expected)).toEqual([2000, 2000, 3000, 3000]);
  });

  it('applies a March payment to the oldest late installment before March due', () => {
    const schedulePlan = plan({
      items: [{ price: 3000 }],
      downPayment: 0,
      initialMonthlyPayment: 1000,
      firstDueDate: '2026-01-01',
    });
    const before = buildSchedule(schedulePlan, '2026-03-01');
    const after = buildSchedule(
      {
        ...schedulePlan,
        payments: [
          {
            amount: 1000,
            paidOn: new Date('2026-03-01T10:00:00Z'),
            method: 'Cash',
            note: null,
          },
        ],
      },
      '2026-03-01',
    );

    expect(before.filter((row) => row.status === 'overdue')).toHaveLength(2);
    expect(after.map((row) => row.paid)).toEqual([1000, 0, 0]);
    expect(after.filter((row) => row.status === 'overdue')).toHaveLength(1);
    expect(after[2].status).toBe('pending');
  });

  it('keeps the original and intervening rates when later rates are added', () => {
    const rows = buildSchedule(
      plan({
        items: [{ price: 17400 }],
        downPayment: 400,
        rateChanges: [
          { fromInstallmentNo: 3, monthlyPayment: 3000 },
          { fromInstallmentNo: 5, monthlyPayment: 1000 },
        ],
      }),
      '2026-10-28',
    );

    expect(rows.map((row) => row.expected)).toEqual([
      2000, 2000, 3000, 3000, 1000, 1000, 1000, 1000, 1000, 1000, 1000,
    ]);
  });

  it('keeps a partially paid installment at its old amount', () => {
    const rows = buildSchedule(
      plan({
        items: [{ price: 10400 }],
        downPayment: 400,
        rateChanges: [{ fromInstallmentNo: 2, monthlyPayment: 3000 }],
        payments: [
          {
            amount: 500,
            paidOn: new Date('2026-11-25T10:00:00Z'),
            method: 'Cash',
            note: null,
          },
        ],
      }),
      '2026-10-28',
    );

    expect(rows.map((row) => row.expected)).toEqual([2000, 3000, 3000, 2000]);
    expect(rows[0].paid).toBe(500);
  });

  it('keeps paid dates unchanged when rescheduling and reports late receipt days', () => {
    const rows = buildSchedule(
      plan({
        items: [{ price: 10400 }],
        downPayment: 400,
        firstDueDate: '2027-10-20',
        scheduleDateChanges: [
          { fromInstallmentNo: 2, firstDueDate: '2027-11-10' },
        ],
        payments: [
          {
            amount: 2000,
            paidOn: new Date('2027-10-30T12:00:00Z'),
            method: 'Cash',
            note: null,
          },
        ],
      }),
      '2027-11-03',
    );

    expect(rows[0]).toMatchObject({
      dueDate: '2027-10-20',
      paid: 2000,
      status: 'paid',
      daysLate: 10,
    });
    expect(rows[1]).toMatchObject({
      dueDate: '2027-11-10',
      status: 'pending',
      daysLate: 0,
    });
    expect(combineInstallmentSchedules([rows])[0].daysLate).toBe(10);
  });

  it('rejects plans that would exceed the schedule limit', () => {
    expect(isValidPlan(5000, 0, 5)).toBe(true);
    expect(isValidPlan(5000, 0, 0)).toBe(false);
    expect(isValidPlan(5000, 0, 4)).toBe(false);
  });
});

describe('multiple purchase plan allocation', () => {
  const createdAt = new Date('2026-11-01T00:00:00Z');
  const plans: MultiPlanInput[] = [
    {
      id: 'a',
      items: [{ name: 'Item A', price: 100000, boughtOn: '2026-10-01' }],
      downPayment: 25000,
      initialMonthlyPayment: 7500,
      firstDueDate: '2026-11-25',
      rateChanges: [],
      createdAt: new Date('2026-10-01T00:00:00Z'),
    },
    {
      id: 'b',
      items: [{ name: 'Item B', price: 30000, boughtOn: '2026-11-01' }],
      downPayment: 0,
      initialMonthlyPayment: 3000,
      firstDueDate: null,
      rateChanges: [],
      createdAt,
    },
  ];

  it('pays Plan A first, then applies the remaining amount to Plan B', () => {
    const schedules = buildMultiPlanSchedules(
      plans,
      [
        {
          amount: 10500,
          paidOn: new Date('2026-11-25T10:00:00Z'),
          createdAt: new Date('2026-11-25T10:00:00Z'),
          method: 'Cash',
          note: null,
        },
      ],
      '2026-11-25',
      '2026-11-25',
    );

    expect(schedules[0][0].paid).toBe(7500);
    expect(schedules[1][0].paid).toBe(3000);
    expect(schedules[0][0].status).toBe('paid');
    expect(schedules[1][0].status).toBe('paid');
  });

  it('shows matching plan qistein as one combined monthly installment', () => {
    const schedules = buildMultiPlanSchedules(
      plans,
      [],
      '2026-11-25',
      '2026-11-25',
    );
    const combined = combineInstallmentSchedules(schedules);

    expect(combined[0]).toMatchObject({
      no: 1,
      dueDate: '2026-11-25',
      expected: 10500,
      paid: 0,
      status: 'pending',
    });
    expect(combined).toHaveLength(schedules[0].length);
  });

  it('shows plans with different due dates as separate installments', () => {
    const datedPlans = plans.map((plan, index) =>
      index === 1 ? { ...plan, firstDueDate: '2026-12-05' } : plan,
    );
    const schedules = buildMultiPlanSchedules(
      datedPlans,
      [],
      '2026-11-25',
      '2026-11-25',
    );
    const combined = combineInstallmentSchedules(schedules);

    expect(combined.slice(0, 2)).toMatchObject([
      { no: 1, dueDate: '2026-11-25', expected: 7500 },
      { no: 1, dueDate: '2026-12-05', expected: 3000 },
    ]);
  });

  it('uses the remaining balance of a partially paid combined installment', () => {
    const schedules = buildMultiPlanSchedules(
      plans,
      [
        {
          amount: 9000,
          paidOn: new Date('2026-11-25T10:00:00Z'),
          createdAt: new Date('2026-11-25T10:00:00Z'),
          method: 'Cash',
          note: null,
        },
      ],
      '2026-11-25',
      '2026-11-25',
    );
    const [next] = combineInstallmentSchedules(schedules);

    expect(next.expected - next.paid).toBe(1500);
  });

  it('reduces monthly total when Plan A is fully paid', () => {
    expect(
      activeMonthlyTotal(
        [
          { remaining: 0, monthly: 7000 },
          { remaining: 25000, monthly: 5000 },
        ],
        12000,
      ),
    ).toBe(5000);
  });

  it('keeps a short payment on Plan A before distributing the remainder', () => {
    const schedules = buildMultiPlanSchedules(
      plans,
      [
        {
          amount: 9000,
          paidOn: new Date('2026-11-25T10:00:00Z'),
          createdAt: new Date('2026-11-25T10:00:00Z'),
          method: 'Cash',
          note: null,
        },
      ],
      '2026-11-25',
      '2026-11-25',
    );

    expect(schedules[0][0].paid).toBe(7500);
    expect(schedules[1][0].paid).toBe(1500);
    expect(schedules[1][0].status).toBe('partial');
  });

  it('uses the full payment for Plan A when it is below Plan A monthly amount', () => {
    const monthlyPlans = plans.map((item, index) => ({
      ...item,
      initialMonthlyPayment: index === 0 ? 6500 : 2500,
    }));
    const schedules = buildMultiPlanSchedules(
      monthlyPlans,
      [
        {
          amount: 4500,
          paidOn: new Date('2026-11-25T10:00:00Z'),
          createdAt: new Date('2026-11-25T10:00:00Z'),
          method: 'Cash',
          note: null,
        },
      ],
      '2026-11-25',
      '2026-11-25',
    );

    expect(schedules[0][0].paid).toBe(4500);
    expect(schedules[1][0].paid).toBe(0);
  });

  it('splits the combined monthly payment after completing Plan A first', () => {
    const monthlyPlans = plans.map((item, index) => ({
      ...item,
      initialMonthlyPayment: index === 0 ? 6500 : 2500,
    }));
    const schedules = buildMultiPlanSchedules(
      monthlyPlans,
      [
        {
          amount: 7500,
          paidOn: new Date('2026-11-25T10:00:00Z'),
          createdAt: new Date('2026-11-25T10:00:00Z'),
          method: 'Cash',
          note: null,
        },
      ],
      '2026-11-25',
      '2026-11-25',
    );

    expect(schedules[0][0].paid).toBe(6500);
    expect(schedules[1][0].paid).toBe(1000);
    expect(schedules[1][0].status).toBe('partial');
    expect(combineInstallmentSchedules(schedules)[0]).toMatchObject({
      expected: 9000,
      paid: 7500,
      status: 'partial',
    });
  });

  it('subtracts Plan B advance from its balance without changing its monthly installment', () => {
    const planB = {
      ...plans[1],
      downPayment: 5000,
      initialMonthlyPayment: 2500,
    };
    const schedules = buildMultiPlanSchedules(
      [planB],
      [],
      '2026-11-25',
      '2026-11-25',
    );

    expect(schedules[0]).toHaveLength(10);
    expect(schedules[0].every((row) => row.expected === 2500)).toBe(true);
    expect(
      planB.downPayment +
        schedules[0].reduce((sum, row) => sum + row.expected, 0),
    ).toBe(30000);
  });

  it('does not allocate earlier payments to a purchase that did not exist yet', () => {
    const schedules = buildMultiPlanSchedules(
      plans,
      [
        {
          amount: 5000,
          paidOn: new Date('2026-10-20T10:00:00Z'),
          createdAt: new Date('2026-10-20T10:00:00Z'),
          method: 'Cash',
          note: null,
        },
      ],
      '2026-11-25',
      '2026-11-25',
    );

    expect(schedules[0][0].paid).toBe(5000);
    expect(schedules[1][0].paid).toBe(0);
  });

  it('starts a new purchase on the base plan’s next unpaid installment date', () => {
    const datedPlans = plans.map((item, index) =>
      index === 1 ? { ...item, scheduleStartDate: '2026-12-25' } : item,
    );
    const schedules = buildMultiPlanSchedules(
      datedPlans,
      [
        {
          amount: 7500,
          paidOn: new Date('2026-11-25T10:00:00Z'),
          createdAt: new Date('2026-11-25T10:00:00Z'),
          method: 'Cash',
          note: null,
        },
        {
          amount: 10500,
          paidOn: new Date('2026-12-25T10:00:00Z'),
          createdAt: new Date('2026-12-25T10:00:00Z'),
          method: 'Cash',
          note: null,
        },
      ],
      '2026-11-25',
      '2026-12-25',
    );

    expect(schedules[0][0].paid).toBe(7500);
    expect(schedules[0][1].paid).toBe(7500);
    expect(schedules[1][0].paid).toBe(3000);
    expect(schedules[0][1].dueDate).toBe(schedules[1][0].dueDate);
  });

  it('applies purchase date changes from the first unpaid installment only', () => {
    const datedPlan = {
      ...plans[0],
      scheduleDateChanges: [
        { fromInstallmentNo: 2, firstDueDate: '2026-12-10' },
      ],
    };
    const schedules = buildMultiPlanSchedules(
      [datedPlan],
      [
        {
          amount: 7500,
          paidOn: new Date('2026-11-30T12:00:00Z'),
          createdAt: new Date('2026-11-30T12:00:00Z'),
          method: 'Cash',
          note: null,
        },
      ],
      '2026-11-25',
      '2026-12-01',
    );

    expect(schedules[0][0]).toMatchObject({
      dueDate: '2026-11-25',
      status: 'paid',
      daysLate: 5,
    });
    expect(schedules[0][1].dueDate).toBe('2026-12-10');
    expect(schedules[0][2].dueDate).toBe('2027-01-10');
  });
});
