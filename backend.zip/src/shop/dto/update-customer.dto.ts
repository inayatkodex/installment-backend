import { ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  Matches,
  Max,
  Min,
} from 'class-validator';

export class UpdateCustomerDto {
  @ApiPropertyOptional({ example: 'Ahmed Khan' })
  @IsOptional()
  @IsString()
  @IsNotEmpty({ message: 'Customer ka naam likhein' })
  name?: string;

  @ApiPropertyOptional({ example: 'Muhammad Ali' })
  @IsOptional()
  @IsString()
  fatherName?: string;

  @ApiPropertyOptional({ example: '0300-1234567' })
  @IsOptional()
  @Matches(/^[0-9+\-\s]{10,15}$/, { message: 'Mobile number sahi likhein' })
  phone?: string;

  @ApiPropertyOptional({ example: '35201-1234567-1' })
  @IsOptional()
  @IsString()
  cnic?: string;

  @ApiPropertyOptional({ example: 'Main Bazaar, Lahore' })
  @IsOptional()
  @IsString()
  address?: string;

  @ApiPropertyOptional({
    example: '2026-11-28',
    description:
      'Agli unpaid qist ki tareekh; pehle se paid qiston ki tareekhein nahi badlengi',
  })
  @IsOptional()
  @Matches(/^\d{4}-\d{2}-\d{2}$/, {
    message: 'Agli baqi qist ki tareekh sahi likhein',
  })
  firstDueDate?: string;

  @ApiPropertyOptional({ example: 2000, description: 'Har mahine ki qist ki raqam' })
  @IsOptional()
  @IsInt({ message: 'Mahine ki qist ki raqam sahi likhein' })
  @Min(1, { message: 'Mahine ki qist ki raqam kam az kam 1 honi chahiye' })
  @Max(2147483647, { message: 'Mahine ki qist ki raqam bohat zyada hai' })
  monthlyPayment?: number;

  @ApiPropertyOptional({ example: 'data:image/jpeg;base64,...' })
  @IsOptional()
  @IsString()
  photo?: string;
}
